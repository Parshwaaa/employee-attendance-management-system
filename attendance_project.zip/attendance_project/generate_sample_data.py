"""Create realistic sample data in data/employees.csv and data/attendance.csv.

Run:  python generate_sample_data.py
(The random seed is fixed, so everybody gets the same data.)
WARNING: this overwrites the existing CSV files.
"""

from datetime import date, timedelta

import numpy as np
import pandas as pd

import config

# name, department, designation, join date, reliability (0-1), monthly drift
EMPLOYEES = [
    ("Aarav Mehta", "IT", "Software Engineer", "2021-06-14", 0.95, -0.010),
    ("Priya Nair", "IT", "Senior Developer", "2019-03-11", 0.97, 0.0),
    ("Rohan Desai", "IT", "QA Engineer", "2022-08-01", 0.90, 0.0),
    ("Sneha Kulkarni", "IT", "System Administrator", "2020-01-20", 0.86, 0.0),
    ("Anjali Shah", "HR", "HR Manager", "2018-05-07", 0.97, 0.0),
    ("Vikram Joshi", "HR", "Recruiter", "2023-02-13", 0.88, 0.0),
    ("Neha Patel", "HR", "HR Executive", "2022-11-21", 0.93, 0.0),
    ("Karan Trivedi", "HR", "Payroll Officer", "2021-09-06", 0.76, -0.020),
    ("Meera Iyer", "Finance", "Accountant", "2020-07-15", 0.96, 0.0),
    ("Rahul Bhatt", "Finance", "Financial Analyst", "2021-04-05", 0.91, 0.0),
    ("Pooja Reddy", "Finance", "Auditor", "2019-10-28", 0.94, 0.0),
    ("Sanjay Verma", "Finance", "Accounts Assistant", "2023-06-12", 0.58, 0.030),
    ("Divya Menon", "Marketing", "Marketing Lead", "2019-08-19", 0.92, 0.0),
    ("Arjun Singh", "Marketing", "Content Writer", "2022-03-14", 0.85, 0.0),
    ("Isha Kapoor", "Marketing", "SEO Specialist", "2023-01-09", 0.89, 0.0),
    ("Nikhil Rao", "Marketing", "Graphic Designer", "2021-12-01", 0.60, 0.030),
    ("Farhan Sheikh", "Operations", "Operations Manager", "2018-11-12", 0.95, 0.0),
    ("Kavya Pillai", "Operations", "Logistics Coordinator", "2020-05-25", 0.90, 0.0),
    ("Manish Gupta", "Operations", "Warehouse Supervisor", "2022-01-17", 0.83, 0.0),
    ("Ritu Sharma", "Operations", "Procurement Officer", "2021-02-22", 0.64, 0.0),
    ("Aditya Malhotra", "Sales", "Sales Manager", "2019-06-03", 0.93, 0.0),
    ("Tanvi Jain", "Sales", "Sales Executive", "2022-09-19", 0.87, 0.0),
    ("Harsh Parekh", "Sales", "Account Executive", "2023-04-24", 0.72, -0.015),
    ("Simran Kaur", "Sales", "Business Development Executive", "2021-08-09", 0.82, 0.0),
]
INACTIVE = {"Simran Kaur": "2026-06-30"}      # left the company on this date

FIRST_DAY, LAST_DAY = date(2026, 4, 1), date(2026, 9, 30)
HOLIDAYS = {date(2026, 5, 1), date(2026, 8, 15), date(2026, 9, 14)}


def working_days():
    day = FIRST_DAY
    while day <= LAST_DAY:
        if day.weekday() < 5 and day not in HOLIDAYS:
            yield day
        day += timedelta(days=1)


def build_tables(seed=42):
    rng = np.random.default_rng(seed)
    employee_rows, attendance_rows = [], []
    for number, (name, dept, role, joined, reliability, drift) in enumerate(EMPLOYEES, 1):
        emp_id = f"E{number:03d}"
        email = name.lower().replace(" ", ".") + "@company.com"
        status = "Inactive" if name in INACTIVE else "Active"
        employee_rows.append([emp_id, name, dept, role, email, joined, status])

        last_day = date.fromisoformat(INACTIVE.get(name, LAST_DAY.isoformat()))
        for day in working_days():
            if day < date.fromisoformat(joined) or day > last_day:
                continue
            months_in = (day.year - FIRST_DAY.year) * 12 + day.month - FIRST_DAY.month
            p_attend = reliability + drift * months_in
            p_attend -= {0: 0.03, 4: 0.02}.get(day.weekday(), 0)   # Monday / Friday dip
            p_attend = float(np.clip(p_attend, 0.5, 0.99))
            if rng.random() < p_attend:
                roll = rng.random()
                result = "Late" if roll < 0.07 else "Half-Day" if roll < 0.10 else "Present"
            else:
                result = "Leave" if rng.random() < 0.20 else "Absent"
            attendance_rows.append([emp_id, day.isoformat(), result])

    employees = pd.DataFrame(employee_rows, columns=config.EMPLOYEE_COLUMNS)
    attendance = pd.DataFrame(attendance_rows, columns=config.ATTENDANCE_COLUMNS)
    return employees, attendance


if __name__ == "__main__":
    config.ensure_directories()
    employees_df, attendance_df = build_tables()
    employees_df.to_csv(config.EMPLOYEES_FILE, index=False)
    attendance_df.to_csv(config.ATTENDANCE_FILE, index=False)
    print(f"Saved {len(employees_df)} employees and {len(attendance_df)} attendance records.")
