import os
import sys
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import analytics
import visualization


def make_data():
    employees = pd.DataFrame({
        "employee_id": ["E001", "E002", "E003", "E004"],
        "name": ["Ann", "Bob", "Cid", "Dee"],
        "department": ["IT", "IT", "HR", "HR"],
        "designation": ["Dev"] * 4,
        "email": [f"{n}@c.com" for n in "abcd"],
        "join_date": ["2024-01-01"] * 4,
        "status": ["Active", "Active", "Active", "Inactive"],
    })
    rows = []
    # Ann: 10 present -> 100 %
    rows += [("E001", f"2026-05-{d:02d}", "Present") for d in range(1, 11)]
    # Bob: 5 present, 2 late, 2 absent, 1 half-day, 2 leave
    #      attended = 5 + 2 + 0.5 = 7.5 ; working days = 10 (leave excluded) -> 75 %
    rows += [("E002", f"2026-05-{d:02d}", s) for d, s in enumerate(
        ["Present"] * 5 + ["Late"] * 2 + ["Absent"] * 2 + ["Half-Day"] + ["Leave"] * 2, 1)]
    # Cid: May 4 present + 6 absent -> 40 %   (June: 10 present -> 100 %)
    rows += [("E003", f"2026-05-{d:02d}", "Present" if d <= 4 else "Absent") for d in range(1, 11)]
    rows += [("E003", f"2026-06-{d:02d}", "Present") for d in range(1, 11)]
    rows += [("E004", "2026-05-01", "Absent")]            # inactive employee
    return employees, pd.DataFrame(rows, columns=["employee_id", "date", "status"])


class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.employees, self.attendance = make_data()

    def summary(self, **kwargs):
        return analytics.employee_summary(self.attendance, self.employees, **kwargs)

    def test_percentage_rules(self):
        s = self.summary(start="2026-05-01", end="2026-05-31").set_index("employee_id")
        self.assertEqual(s.loc["E001", "attendance_pct"], 100.0)
        self.assertEqual(s.loc["E002", "attendance_pct"], 75.0)     # leave excluded
        self.assertEqual(s.loc["E002", "working_days"], 10)
        self.assertEqual(s.loc["E003", "attendance_pct"], 40.0)
        self.assertNotIn("E004", s.index)                             # inactive hidden

    def test_levels_and_lists(self):
        s = self.summary(start="2026-05-01", end="2026-05-31")
        self.assertEqual(list(analytics.low_attendance(s, 75)["employee_id"]), ["E003"])
        self.assertEqual(list(analytics.high_attendance(s, 90)["employee_id"]), ["E001"])
        levels = dict(zip(s["employee_id"], s["level"]))
        self.assertEqual(levels, {"E001": "High", "E002": "Average", "E003": "Low"})

    def test_no_data_employee(self):
        s = self.summary(start="2030-01-01").set_index("employee_id")
        self.assertTrue(s["attendance_pct"].isna().all())
        self.assertEqual(set(s["level"]), {"No Data"})

    def test_department_summary_is_weighted(self):
        s = self.summary(start="2026-05-01", end="2026-05-31")
        dept = analytics.department_summary(s).set_index("department")
        self.assertAlmostEqual(dept.loc["IT", "attendance_pct"], (10 + 7.5) / 20 * 100)
        self.assertEqual(dept.loc["IT", "rank"], 1)

    def test_period_comparison(self):
        people, depts, overall = analytics.period_comparison(
            self.attendance, self.employees,
            "2026-05-01", "2026-05-31", "2026-06-01", "2026-06-30")
        cid = people.set_index("employee_id").loc["E003"]
        self.assertEqual((cid["period_a_pct"], cid["period_b_pct"]), (40.0, 100.0))
        self.assertEqual(cid["trend"], "Improved")
        self.assertEqual(depts.set_index("department").loc["HR", "change"], 60.0)
        self.assertEqual(overall["change"], round(overall["period_b"] - overall["period_a"], 2))

    def test_statistics_and_trend(self):
        stats = analytics.basic_statistics(self.summary(start="2026-05-01", end="2026-05-31"))
        self.assertAlmostEqual(stats["Mean attendance %"], np.mean([100, 75, 40]), places=2)
        trend = analytics.monthly_trend(self.attendance, self.employees)
        self.assertEqual(list(trend.index), ["2026-05", "2026-06"])
        self.assertEqual(trend.loc["2026-06", "Overall"], 100.0)

    def test_charts_build_for_every_type(self):
        filters = {"start": "2026-05-01", "end": "2026-05-31",
                   "start_b": "2026-06-01", "end_b": "2026-06-30", "department": "All"}
        for name in visualization.CHART_TYPES:
            figure = visualization.create_chart(name, self.attendance, self.employees, filters)
            self.assertTrue(figure.axes, name)

    def test_empty_data_does_not_crash(self):
        empty = pd.DataFrame(columns=["employee_id", "date", "status"])
        s = analytics.employee_summary(empty, self.employees)
        self.assertEqual(len(s), 3)
        self.assertTrue(np.isnan(analytics.overall_percentage(s)))
        fig = visualization.create_chart(visualization.CHART_TYPES[0], empty, self.employees, {})
        self.assertTrue(fig.axes)


if __name__ == "__main__":
    unittest.main()
