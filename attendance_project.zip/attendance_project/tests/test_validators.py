import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from validators import (ValidationError, parse_date, parse_optional_date, parse_percentage,
                        validate_date_range, validate_email, validate_name,
                        validate_thresholds)


class ValidatorTests(unittest.TestCase):
    def test_name(self):
        self.assertEqual(validate_name("  Asha   Rao "), "Asha Rao")
        for bad in ("", "A", "R2D2", "x" * 70):
            with self.assertRaises(ValidationError):
                validate_name(bad)

    def test_email(self):
        self.assertEqual(validate_email(" Test@Company.COM "), "test@company.com")
        for bad in ("", "no-at-sign", "a@b", "a b@c.com"):
            with self.assertRaises(ValidationError):
                validate_email(bad)

    def test_dates(self):
        self.assertEqual(parse_date("2026-4-5"), "2026-04-05")
        self.assertIsNone(parse_optional_date("   "))
        with self.assertRaises(ValidationError):
            parse_date("31/12/2026")
        with self.assertRaises(ValidationError):
            parse_date("2026-02-30")
        with self.assertRaises(ValidationError):
            parse_date("2999-01-01", allow_future=False)

    def test_ranges_and_thresholds(self):
        validate_date_range("2026-01-01", "2026-02-01")
        with self.assertRaises(ValidationError):
            validate_date_range("2026-03-01", "2026-02-01")
        self.assertEqual(parse_percentage("75.5"), 75.5)
        for bad in ("abc", "-1", "101"):
            with self.assertRaises(ValidationError):
                parse_percentage(bad)
        with self.assertRaises(ValidationError):
            validate_thresholds(90, 75)


if __name__ == "__main__":
    unittest.main()
