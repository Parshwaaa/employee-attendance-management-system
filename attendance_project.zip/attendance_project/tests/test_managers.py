import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from attendance_manager import AttendanceManager
from employee_manager import EmployeeManager
from validators import ValidationError


class EmployeeManagerTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.path = Path(self.folder.name) / "employees.csv"
        self.manager = EmployeeManager(self.path)

    def tearDown(self):
        self.folder.cleanup()

    def add(self, name="Asha Rao", dept="IT", email="asha@company.com"):
        return self.manager.add_employee(name, dept, "Developer", email, "2024-01-15")

    def test_add_generates_ids_and_saves(self):
        self.assertEqual(self.add(), "E001")
        self.assertEqual(self.add("Ben Cook", "HR", "ben@company.com"), "E002")
        reloaded = EmployeeManager(self.path)           # proves it was written to CSV
        self.assertEqual(len(reloaded.get_all()), 2)

    def test_duplicate_email_rejected(self):
        self.add()
        with self.assertRaises(ValidationError):
            self.add("Other Person")

    def test_update_and_delete(self):
        emp_id = self.add()
        self.manager.update_employee(emp_id, "Asha Rao", "HR", "Lead", "asha@company.com",
                                     "2024-01-15", "Inactive")
        employee = self.manager.get_employee(emp_id)
        self.assertEqual((employee["department"], employee["status"]), ("HR", "Inactive"))
        self.manager.delete_employee(emp_id)
        self.assertIsNone(self.manager.get_employee(emp_id))
        with self.assertRaises(ValidationError):
            self.manager.delete_employee(emp_id)

    def test_search_and_filters(self):
        self.add()
        self.add("Ben Cook", "HR", "ben@company.com")
        self.assertEqual(len(self.manager.search("cook")), 1)
        self.assertEqual(len(self.manager.search(department="IT")), 1)
        self.assertEqual(len(self.manager.search(status="Inactive")), 0)
        self.assertEqual(self.manager.departments(), ["HR", "IT"])


class AttendanceManagerTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.path = Path(self.folder.name) / "attendance.csv"
        self.manager = AttendanceManager(self.path)

    def tearDown(self):
        self.folder.cleanup()

    def test_mark_overwrites_same_day(self):
        self.manager.mark("E001", "2026-05-04", "Present")
        self.manager.mark("E001", "2026-05-04", "Absent")
        self.assertEqual(len(self.manager.get_all()), 1)
        self.assertEqual(self.manager.get_for_date("2026-05-04"), {"E001": "Absent"})

    def test_validation(self):
        with self.assertRaises(ValidationError):
            self.manager.mark("E001", "2026-05-04", "Sleeping")
        with self.assertRaises(ValidationError):
            self.manager.mark("E001", "2999-01-01", "Present")
        with self.assertRaises(ValidationError):
            self.manager.mark("E999", "2026-05-04", "Present", valid_ids={"E001"})

    def test_queries_and_removal(self):
        self.manager.mark_many("2026-05-04", {"E001": "Present", "E002": "Late"})
        self.manager.mark("E001", "2026-05-05", "Leave")
        history = self.manager.get_for_employee("E001", start="2026-05-05")
        self.assertEqual(list(history["status"]), ["Leave"])
        self.assertEqual(self.manager.date_range(), ("2026-05-04", "2026-05-05"))
        self.assertEqual(self.manager.remove_marks("2026-05-04", ["E001"]), 1)
        self.assertEqual(self.manager.delete_employee_records("E001"), 1)
        self.assertEqual(len(AttendanceManager(self.path).get_all()), 1)


if __name__ == "__main__":
    unittest.main()
